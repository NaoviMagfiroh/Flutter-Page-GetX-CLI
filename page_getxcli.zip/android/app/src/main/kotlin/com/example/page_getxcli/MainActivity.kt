package com.example.page_getxcli

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
